<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment Successful</title>
</head>
<body>
  <h2>✅ Your GCash payment was successfully submitted!</h2>
  <a href="index.php">← Back to Home</a>
</body>
</html>
